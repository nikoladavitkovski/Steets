using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

static bool IsPrime(int number)
{
    if (number <= 1) return false;
    if (number == 2) return true;
    if (number % 2 == 0) return false;

    var boundary = (int)Math.Floor(Math.Sqrt(number));

    for (int i = 3; i <= boundary; i += 2)
        if (number % i == 0)
            return false;

    return true;
}

static string GetChristmasDay(int year)
{
    DateTime result = new(year, 1, 1);
    return result.DayOfWeek.ToString();
}

MySql.Data.MySqlClient.MySqlConnection conn;
string myConnectionString = "server=127.0.0.1;uid=root;" +
    "pwd=12345;database=years";

conn = new MySql.Data.MySqlClient.MySqlConnection();
conn.ConnectionString = myConnectionString;
conn.Open();

var encryptionKey = "someKey";

var cmd = new MySqlCommand($"INSERT INTO Years (year, day) VALUES(@year, AES_ENCRYPT(@day, '{encryptionKey}'))", connection: conn);

app.MapPost("/year", ([FromForm] int year) =>
{
    int numPrimes = 0;
    int tmpYear = year;
    while (numPrimes < 30 && tmpYear > 0)
    {
        if (IsPrime(tmpYear))
        {
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@year", tmpYear);
            cmd.Parameters.AddWithValue("@day", GetChristmasDay(tmpYear));
            cmd.Prepare();

            cmd.ExecuteNonQuery();
            numPrimes++;
        }
        tmpYear--;
    }

    var getCmd = new MySqlCommand($"SELECT id, year, AES_DECRYPT(day, '{encryptionKey}') as day FROM Years", connection: conn);
    using var reader = getCmd.ExecuteReader();
    List<YearRecord> result = new();
    while (reader.Read())
    {
        result.Add(new YearRecord(
            reader.GetInt32("id"),
            reader.GetInt32("year"),
            reader.GetString("day"))
            );
    }

    return result;
})
.WithName("PostYear");

app.Run();

internal record YearRecord(int Id, int Year, string Day);